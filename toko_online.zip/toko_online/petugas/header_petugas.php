<?php 
session_start();
    if($_SESSION['status_login']!=true){
        header('location: login_petugas.php');
    }
    include "../koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Petugas</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/sticky-footer-navbar/">

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../custom.css" rel="stylesheet">

    <style>
    ul {
      display: block;
      list-style-type: none;
    }
    </style>
  </head>


<body>

  <header>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container px-4 px-lg-5">
  <a class="navbar-brand" href="#">Toko Pertanian Pak Nanda</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tam_produk.php">Produk</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tam_petugas.php">Petugas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tam_pelanggan.php">Pelanggan</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="transaksi.php">Transaksi</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>

    </form>
    <a class="btn btn-danger my-2 my-sm-" href="logout_petugas.php" role="button">logout</a>
  </div>
  </div>
</nav>
  </header>