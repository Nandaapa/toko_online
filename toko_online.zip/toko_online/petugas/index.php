<?php 
    include "header_petugas.php";
?>

    <!-- Begin page content -->
    <main role="main" class="container">
      <h1 class="mt-5">Selamat datang di Toko pertanian Pak nanda.</h1>
      <p></p>
      <p class="lead">Anda login sebagai <?=$_SESSION['level']?> <?=$_SESSION['nama_petugas']?></p>
  
<div class="w3-content w3-section" style="max-width:500px">
  <img class="mySlides" src="../images/produk/em4.jpg" style="width:100%">
  <img class="mySlides" src="../images/produk/virtako.jpeg" style="width:100%">
  <img class="mySlides" src="../images/produk/profozz.jpg" style="width:100%">
  <img class="mySlides" src="../images/produk/npk mutiara.jpg" style="width:100%">
  <img class="mySlides" src="../images/produk/sidamethrin.jpg" style="width:100%">
  <img class="mySlides" src="../images/toko_pertanian.jpg" style="width:100%">
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>

    </main>

<?php
    include "footer_petugas.php";
?>