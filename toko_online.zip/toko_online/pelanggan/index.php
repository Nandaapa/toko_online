        <!-- Section-->
        <?php 
include "header.php";
    include "../koneksi.php";
?>
<!-- Header-->
<header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Toko Pertanian Pak Nanda</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Harga Ramah dan berkualitas</p>
                </div>
            </div>
        </header>
        
        <main role="main" class="container">
      <h1 class="mt-5">Selamat datang di website Toko Pertanian Pak Nanda.</h1>
      <p></p>
      <p class="lead">Anda login sebagai <?=$_SESSION['nama_pelanggan']?></p>
      <p></p>
    </main>
<main role="main" class="container">
<div class="row">
   <img src="../images/toko_pertanian.jpg" alt="" srcset="" style="width: 1000px; ;">

  

</div>
</main>

<?php
include "footer.php";
?>
