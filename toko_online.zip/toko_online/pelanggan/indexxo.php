<?php 
    include "header.php";
?>

    <!-- Begin page content -->
    <main role="main" class="container">
      <h1 class="mt-5">Selamat datang di website Toko XIR2.</h1>
      <p></p>
      <p class="lead">Anda login sebagai <?=$_SESSION['nama_pelanggan']?></p>
      <p></p>
    </main>

<?php
    include "footer.php";
?>